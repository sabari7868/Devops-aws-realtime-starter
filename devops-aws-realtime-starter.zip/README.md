# DevOps AWS Realtime Starter

Account: 662792376491
Region: us-east-1
Domain: sabaridevops.cloud

See terraform/README in repo for usage.
